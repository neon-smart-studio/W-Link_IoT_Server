#!/usr/bin/env bash
set -e

function info { echo -e "\e[32m[info] $*\e[39m"; }
function warn  { echo -e "\e[33m[warn] $*\e[39m"; }
function error { echo -e "\e[31m[error] $*\e[39m"; exit 1; }

ARCH=$(uname -m)

BINARY_DOCKER=/usr/bin/docker

DOCKER_REPO=homeassistant

SERVICE_DOCKER="/etc/init.d/docker"
SERVICE_NM="/etc/init.d/network-manager"

FILE_DOCKER_CONF="/etc/docker/daemon.json"
FILE_INTERFACES="/etc/network/interfaces"
FILE_NM_CONF="/etc/NetworkManager/NetworkManager.conf"
FILE_NM_CONNECTION="/etc/NetworkManager/system-connections/default"

URL_RAW_BASE="https://raw.githubusercontent.com/home-assistant/supervised-installer/master/files"
URL_VERSION_HOST="version.home-assistant.io"
URL_VERSION="https://${URL_VERSION_HOST}/stable.json"
URL_APPARMOR_PROFILE="https://version.home-assistant.io/apparmor.txt"

# Detect wrong docker logger config
if [ ! -f "$FILE_DOCKER_CONF" ]; then
  # Write default configuration
  info "Creating default docker daemon configuration $FILE_DOCKER_CONF"
  cp ./files/docker_daemon.json "${FILE_DOCKER_CONF}"

  # Restart Docker service
  info "Restarting docker service"
  "$SERVICE_DOCKER" restart
else
  STORAGE_DRIVER=$(docker info -f "{{json .}}" | jq -r -e .Driver)
  if [[ "$STORAGE_DRIVER" != "overlay2" ]]; then
    warn "Docker is using $STORAGE_DRIVER and not 'overlay2' as the storage driver, this is not supported."
  fi
fi

# Check dmesg access
if [[ "$(sysctl -n kernel.dmesg_restrict)" != "0" ]]; then
    info "Fix kernel dmesg restriction"
    echo 0 > /proc/sys/kernel/dmesg_restrict
    echo "kernel.dmesg_restrict=0" >> /etc/sysctl.conf
fi

# Create config for NetworkManager
info "Creating NetworkManager configuration"
cp ./files/NetworkManager.conf "${FILE_NM_CONF}"
if [ ! -f "$FILE_NM_CONNECTION" ]; then
    cp ./files/system-connection-default "${FILE_NM_CONNECTION}"
fi

warn "Changes are needed to the /etc/network/interfaces file"
info "If you have modified the network on the host manualy, those can now be overwritten"
info "If you do not overwrite this now you need to manually adjust it later"
info "Do you want to proceed with overwriting the /etc/network/interfaces file? [N/y] "
read answer < /dev/tty

if [[ "$answer" =~ "y" ]] || [[ "$answer" =~ "Y" ]]; then
    info "Replacing /etc/network/interfaces"
    cp ./files/interfaces "${FILE_INTERFACES}"
fi

info "Restarting NetworkManager"
"${SERVICE_NM}" restart

# Parse command line parameters
while [[ $# -gt 0 ]]; do
    arg="$1"

    case $arg in
        -d|--data-share)
            DATA_SHARE=$2
            shift
            ;;
        -p|--prefix)
            PREFIX=$2
            shift
            ;;
        -s|--sysconfdir)
            SYSCONFDIR=$2
            shift
            ;;
        *)
            error "Unrecognized option $1"
            ;;
    esac
    shift
done

PREFIX=${PREFIX:-/usr}
SYSCONFDIR=${SYSCONFDIR:-/etc}
DATA_SHARE=${DATA_SHARE:-$PREFIX/share/hassio}
CONFIG=$SYSCONFDIR/hassio.json

# Generate hardware options
case $ARCH in
    "i386" | "i686")
        HASSIO_DOCKER="$DOCKER_REPO/i386-hassio-supervisor"
    ;;
    "x86_64")
        HASSIO_DOCKER="$DOCKER_REPO/amd64-hassio-supervisor"
    ;;
    "arm" |"armv6l")
        HASSIO_DOCKER="$DOCKER_REPO/armhf-hassio-supervisor"
    ;;
    "armv7l")
        HASSIO_DOCKER="$DOCKER_REPO/armv7-hassio-supervisor"
    ;;
    "aarch64")
        HASSIO_DOCKER="$DOCKER_REPO/aarch64-hassio-supervisor"
    ;;
    *)
        error "$ARCH unknown!"
    ;;
esac

### Main

# Init folders
if [ ! -d "$DATA_SHARE" ]; then
    mkdir -p "$DATA_SHARE"
fi

if [ ! -d "${PREFIX}/sbin" ]; then
    mkdir -p "${PREFIX}/sbin"
fi

if [ ! -d "${PREFIX}/bin" ]; then
    mkdir -p "${PREFIX}/bin"
fi
# Read infos from web
while ! ping -c 1 -W 1 ${URL_VERSION_HOST}; do
    info "Waiting for ${URL_VERSION_HOST} - network interface might be down..."
    sleep 2
done
HASSIO_VERSION=$(curl -s $URL_VERSION | jq -e -r '.supervisor')

##
# Write configuration
cat > "$CONFIG" <<- EOF
{
    "supervisor": "${HASSIO_DOCKER}",
    "machine": "openwrt",
    "data": "${DATA_SHARE}"
}
EOF

##
# Pull supervisor image
info "Install supervisor Docker container"
docker pull "$HASSIO_DOCKER:$HASSIO_VERSION" > /dev/null
docker tag "$HASSIO_DOCKER:$HASSIO_VERSION" "$HASSIO_DOCKER:latest" > /dev/null

##
# Install Hass.io Supervisor
info "Install supervisor startup scripts"
cp ./files/hassio-supervisor "${PREFIX}/sbin/hassio-supervisor"
cp ./files/hassio-supervisor.init "${SYSCONFDIR}/init.d/hassio-supervisor.init"

sed -i "s,%%HASSIO_CONFIG%%,${CONFIG},g" "${PREFIX}"/sbin/hassio-supervisor
sed -i -e "s,%%BINARY_DOCKER%%,${BINARY_DOCKER},g" \
       -e "s,%%BINARY_HASSIO%%,sh ${PREFIX}/sbin/hassio-supervisor,g" \
       "${SYSCONFDIR}/init.d/hassio-supervisor.init"

chmod a+x "${PREFIX}/sbin/hassio-supervisor"

#
# Install Hass.io AppArmor
info "Install AppArmor scripts"
mkdir -p "${DATA_SHARE}/apparmor"
cp ./files/hassio-apparmor "${PREFIX}/sbin/hassio-apparmor"
cp ./files/hassio-apparmor.init "${SYSCONFDIR}/init.d/hassio-apparmor.init"
curl -sL ${URL_APPARMOR_PROFILE} > "${DATA_SHARE}/apparmor/hassio-supervisor"

sed -i "s,%%HASSIO_CONFIG%%,${CONFIG},g" "${PREFIX}/sbin/hassio-apparmor"
sed -i -e "s,%%HASSIO_APPARMOR_BINARY%%,sh ${PREFIX}/sbin/hassio-apparmor,g" \
    "${SYSCONFDIR}/init.d/hassio-apparmor.init"

chmod a+x "${PREFIX}/sbin/hassio-apparmor"
"${SYSCONFDIR}/init.d/hassio-apparmor.init" start


##
# Init system
info "Start Home Assistant Supervised"
"${SYSCONFDIR}/init.d/hassio-supervisor.init" start

##
# Setup CLI
info "Installing the 'ha' cli"
cp ./files/ha "${PREFIX}/bin/ha"
chmod a+x "${PREFIX}/bin/ha"